##Android Chat Starter

A sample Android App which can be used as a starter application for a chat application.

###What it includes?

* Native Emoji Keyboard - Same as found in WhatsApp
* Chat bubbles - Modeled after WhatsApp

###Screenshots

<img src="https://github.com/madhur/android-chat-starter/blob/gh-pages/chat1.png" />
<img src="https://github.com/madhur/android-chat-starter/blob/gh-pages/chat2.png" />
